<?php
$sql = new mysqli('localhost', 'root', '', 'noite');
?>